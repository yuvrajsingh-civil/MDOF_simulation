clear; clc; close all;

%Input

N=4;                   %Number of stories
Ks=1000;               %Interstory stiffness
Ms=5;                  %Floor mass
fs=100;                %Sampling frequency
ag=randn(1,10000);     %Ground acceleration

%----------------------------
%Processing

M=Ms*diag(ones(N,1));                  %Mass matrix
K=MultiStory_Stiffness(Ks,N);          %Stiffness matrix
C=0.01*M+0.01*K;                       %Damping matrix
f=-M*ones(N,1).*ag;                    %Effective force
Result=MDOF_simulation(M,C,K,f,fs);    %MDOF solver

%----------------------------
%Plot Response

t=[0:1/fs:(length(ag)-1)/fs];

figure;

for i=1:1:N
    
subplot(N,3,3*i-2)
plot(t,Result.Acceleration(i,:)); xlabel('Time (sec)'); ylabel(strcat('ACC',num2str(i)));
subplot(N,3,3*i-1)
plot(t,Result.Velocity(i,:)); xlabel('Time (sec)'); ylabel(strcat('VEL',num2str(i)));
subplot(N,3,3*i)
plot(t,Result.Displacement(i,:)); xlabel('Time (sec)'); ylabel(strcat('DSP',num2str(i)));
        
end
    
%---------------------------
%Plot Modeshapes

figure;

for i=1:1:N
plot([0 ; Result.Parameters.ModeShape(:,i)],0:N,'*-');
hold on
end
hold off
xlabel('Amplitude');
ylabel('Floor');
grid on
daspect([1 1 1]);
title('Modeshapes');