function K=MultiStory_Stiffness(Ks,N)

%Input
%Ks: Interstory stiffness of columns
%N: Number of storys

%Output
%K: Stiffness matrix

KK=Ks*ones(N+1,1);
KK(N+1)=0;
K=zeros(N,N);

for i=1:1:N
for j=1:1:N              
if i==j 
K(i,j)=KK(i)+KK(i+1);
end            
if i==j+1
K(i,j)=-KK(i);
end      
if j==i+1
K(i,j)=-KK(j);
end        
end
end

end



